# 配置中心
路径classpath:/configs下
dev文件夹下是开发环境目录
对应各个微服务的bootstrap.yml里的profile: dev
默认以各个服务的{spring.application.name}.yml
暂时放在本地，有条件者可将配置文件放在git
随机端口号，支持启动多个实例
