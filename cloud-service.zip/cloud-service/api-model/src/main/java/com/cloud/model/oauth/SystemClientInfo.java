package com.cloud.model.oauth;

/**
 * 自己系统的client信息
 * 2018.07.10 定义
 */
public interface SystemClientInfo {

    String CLIENT_ID = "system";
    String CLIENT_SECRET = "system";
    String CLIENT_SCOPE = "app";
}
