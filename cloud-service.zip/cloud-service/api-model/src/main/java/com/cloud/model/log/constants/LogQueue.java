package com.cloud.model.log.constants;

public interface LogQueue {

	/**
	 * 接收日志的队列名
	 */
	String LOG_QUEUE = "system.log.queue";
}
